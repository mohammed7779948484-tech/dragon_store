/**
 * Theme config (Single Source of Truth)
 * 
 * Defines the core design system tokens including colors, typography,
 * and radii. This configuration enforces the Deep Obsidian and Electric Lime
 * brand palette across the application as per design audit and guidelines.
 * 
 * Note: These values map to the CSS variables in src/app/globals.css
 */

export const themeConfig = {
    colors: {
        // Core Palette
        background: '#0F1111',  // Deep Obsidian (Dark Theme Default)
        foreground: '#E8ECEF',  // Cloud White

        // Surfaces
        surface: '#181B1F',     // Cards / Popovers
        surfaceForeground: '#E8ECEF',

        // Brand & Accents
        primary: '#B4FF3B',     // Electric Lime
        primaryForeground: '#0F1111',
        secondary: '#1A202C',
        secondaryForeground: '#E8ECEF',

        // States & Interactions
        muted: '#1E2429',
        mutedForeground: '#A0AEC0',
        accent: '#B4FF3B',
        accentForeground: '#0F1111',
        destructive: '#E53E3E',
        destructiveForeground: '#E8ECEF',

        // UI Elements
        border: '#2D3748',
        input: '#2D3748',
    },
    radii: {
        sm: '0.375rem',
        md: '0.5rem',
        lg: '0.75rem',
        xl: '1rem',
    },
} as const;

export type ThemeConfig = typeof themeConfig;
